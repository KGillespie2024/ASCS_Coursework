// Kai Gillespie 20240310
import java.util.*;

public class Lab9_Task2 {
    public static void main(String[] args) {
        
        // Create the first tree structure
    	TreeNode<Integer> root1 = new TreeNode<Integer>();
    	root1.data = 1;
        TreeNode<Integer> three = root1.addChild(new TreeNode<Integer>(3));
        TreeNode<Integer> two =   root1.addChild(new TreeNode<Integer>(2));
        TreeNode<Integer> four =  three.addChild(new TreeNode<Integer>(4));
        TreeNode<Integer> six =   three.addChild(new TreeNode<Integer>(6));
        TreeNode<Integer> five =    two.addChild(new TreeNode<Integer>(5));

        // Perform breadth-first search on the first tree
        System.out.println("Breadth-first search of tree 1:");
        breadthFirstSearch(root1);

        // Create the second tree structure
        TreeNode<Integer> root2 = new TreeNode<Integer>(6);
        TreeNode<Integer> five2 = root2.addChild(new TreeNode<Integer>(5));
        TreeNode<Integer> three2 = root2.addChild(new TreeNode<Integer>(3));
        TreeNode<Integer> four2 = five2.addChild(new TreeNode<Integer>(4));
        TreeNode<Integer> two2 = three2.addChild(new TreeNode<Integer>(2));
        TreeNode<Integer> one = three2.addChild(new TreeNode<Integer>(1));

        // Perform breadth-first search on the second tree
        System.out.println("Breadth-first search of tree 2:");
        breadthFirstSearch(root2);
    }

	// breadthFirstSearch
	// Enumerates all nodes in a tree
	// Displays the tree and enumerated list of nodes to the console
	public static <T> void breadthFirstSearch (TreeNode<T> root)	
	{
		// A class that implements the Set interface
		ArrayList<TreeNode<T>> s = new ArrayList<>();
		
		// A class that implements the Queue interface
		ArrayDeque<TreeNode<T>> q = new ArrayDeque<>();
		
		// Run a breadth-first search
		s.add(root);
		q.offer(root);
		
		while (!q.isEmpty() ){
			TreeNode<T> current = q.remove();
			for (TreeNode<T> i: current.getChildren()) {
				if (! s.contains(i)) {
					s.add(i);
					q.offer(i);
				}
			}
 		}
		
		// Output results
		outputTree (root);
		
		System.out.println("Has results:");
		for (TreeNode<T> i: s) {
			System.out.print(i.data + " ");
		}
		System.out.println();
		System.out.println();
	}
	
	// ouputTree
	// Prints a tree to the console
	// Students do not need to modify this code.
	public static <T> void outputTree (TreeNode<T> t) {
		
		if (t.getParent() == null)
			System.out.print("Root node: " );
		
		// This recurses repeatedly through the parents of each branch of the tree
		// This is O(n^2) and could be dramatically improved.
		TreeNode<T> parent = t.getParent();
		while (parent != null) {
			System.out.print("  ");
			parent = parent.getParent();
		} 
		System.out.println(t.data);
		
		for (TreeNode<T> a : t.getChildren())
			outputTree(a);
	}
}