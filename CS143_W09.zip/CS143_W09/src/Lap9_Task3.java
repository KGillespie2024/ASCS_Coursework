// Kai Gillespie 20240310
import java.io.*;

public class Lap9_Task3 {
    public static void main(String[] args) throws IOException {
        String[] stringsToWrite = {"Hello", "World", "Java", "Programming", "Lab10"};
        String filePath = "lab10.txt";

        // Write strings to the file
        try (FileWriter writer = new FileWriter(filePath)) {
            for (String string : stringsToWrite) {
                writer.write(string + System.lineSeparator());
            }
        } catch (IOException e) {
            System.err.println("An error occurred while writing to the file: " + e.getMessage());
            return;
        }

        // Read strings back into different variables
        String string1, string2, string3, string4, string5;
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            string1 = reader.readLine();
            string2 = reader.readLine();
            string3 = reader.readLine();
            string4 = reader.readLine();
            string5 = reader.readLine();
        } catch (IOException e) {
            System.err.println("An error occurred while reading from the file: " + e.getMessage());
            return;
        }

        // Output the read strings to verify the operation
        System.out.println("String 1: " + string1);
        System.out.println("String 2: " + string2);
        System.out.println("String 3: " + string3);
        System.out.println("String 4: " + string4);
        System.out.println("String 5: " + string5);
    }
}
