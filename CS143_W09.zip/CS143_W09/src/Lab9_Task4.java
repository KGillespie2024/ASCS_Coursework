// Kai Gillespie 20240310

public class Lab9_Task4 {

    public static void main(String[] args) {
        permute("", "POEM");
    }

    public static void permute(String chosen, String available) {
        if (available.length() == 0) {
            System.out.println(chosen);
        } else {
            for (int i = 0; i < available.length(); i++) {
                char c = available.charAt(i);
                chosen += c;
                permute(chosen, available.substring(0, i) + available.substring(i + 1));
                chosen = chosen.substring(0, chosen.length() - 1);
            }
        }
    }
}
