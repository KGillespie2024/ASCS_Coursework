// Kai Gillespie 20240306

import java.util.*;

public class SetDemo {

    public static void main(String args[]) {
    	// Array of integers to be added to the set
        int count[] = {34, 22,10,60,30,22};
        
        // Creating an unsorted set using HashSet
        Set<Integer> unsortedSet = new HashSet<Integer>();
        try {
        	// Adding elements from the array to the unsorted set
            for(int i = 0; i < count.length; i++) {
                unsortedSet.add(count[i]);
            }
            // Printing the unsorted set
            System.out.println("The unsorted set is: " + unsortedSet);
            
            

            // Creating a sorted set from the unsorted set using TreeSet
            TreeSet<Integer> sortedSet = new TreeSet<Integer>(unsortedSet);
            
            // Printing the sorted set
            System.out.println("The sorted set is: " + sortedSet);
            
            

            // Printing the first and last element of the sorted set
            System.out.println("The First element of the set is: " +
                               (Integer)sortedSet.first());
            System.out.println("The last element of the set is: " +
                               (Integer)sortedSet.last());
            
         // 1.1 Check if the unsorted set contains the value 20
            boolean contains20Before = unsortedSet.contains(20);
            System.out.println("1.1 Unsorted set contains 20: " + contains20Before);
            
         // 1.2 Checking if the sorted set contains the value 7
            boolean contains7 = sortedSet.contains(7);
            System.out.println("1.2 Sorted set contains 7: " + contains7);
            
         // 1.3 Remove the element 20 from the unsorted set
            boolean isRemoved = unsortedSet.remove(20);
            System.out.println("1.3 Element 20 removed from unsorted set: " + isRemoved);

         // 1.4 Test to see if the unsorted set still contains the value 20
            boolean contains20After = unsortedSet.contains(20);
            System.out.println("1.4 Unsorted set contains 20 after removal: " + contains20After);

         // 1.5 Add the value 3 to the sorted set
            boolean isAdded = sortedSet.add(3);
            System.out.println("1.5 Element 3 added to sorted set: " + isAdded);

         // 1.6 Test to see if the sorted set contains the value 3
            boolean contains3 = sortedSet.contains(3);
            System.out.println("1.6 Sorted set contains 3: " + contains3);

         // 1.7 Display the unsorted set
            System.out.println("1.7 Unsorted set: " + unsortedSet);

         // 1.8 Display the sorted set
            System.out.println("1.8 Sorted set: " + sortedSet);

         // 1.9 Add all values from the sorted set to the unsorted set
            unsortedSet.addAll(sortedSet);

         // 1.10 Display both sets and confirm they have the same contents
            //Display
            System.out.println("1.10 Unsorted set after adding all from sorted set: " + unsortedSet);
            System.out.println("1.10 Sorted set after adding all from sorted set: " + sortedSet);
            
            //Confirm
            boolean sameContents = unsortedSet.containsAll(sortedSet) && sortedSet.containsAll(unsortedSet);
            System.out.println("1.10 Do both sets have the same contents? " + sameContents);
            
        }
        catch(Exception e) {}
    }
}
